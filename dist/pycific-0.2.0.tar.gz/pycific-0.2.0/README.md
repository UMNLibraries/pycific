# pycific
Pacific python programming via validation and immutability
